# PatchPilot — HackNex HNX26PSI09

Run: `pip install -r requirements.txt` then `streamlit run app.py`.
The built-in demo works without an API key.
