import streamlit as st
from pathlib import Path
import tempfile
import json
from agent import inspect_repo, propose_patch, apply_patch, run_tests, safe_extract_zip, make_demo_repo

st.set_page_config(page_title="PatchPilot AI", page_icon="🛠️", layout="wide", initial_sidebar_state="expanded")

st.markdown("""
<style>
.block-container {padding-top: 2rem; padding-bottom: 3rem; max-width: 1500px;}
.hero {padding: 1.4rem 1.6rem; border: 1px solid rgba(128,128,128,.25); border-radius: 18px; background: linear-gradient(135deg, rgba(70,90,130,.16), rgba(40,45,60,.10)); margin-bottom: 1rem;}
.hero h1 {font-size: 2.6rem; margin-bottom: .2rem;}
.hero p {font-size: 1.05rem; color: #aeb4c0; margin: 0;}
.step {padding: .8rem 1rem; border-radius: 12px; border: 1px solid rgba(128,128,128,.2); text-align:center; min-height: 90px;}
.step b {font-size: 1rem;}
.small {color:#9ca3af; font-size:.86rem;}
</style>
""", unsafe_allow_html=True)

st.markdown("""
<div class="hero">
<h1>🛠️ PatchPilot — AI Software Engineering Agent</h1>
<p>Understand a codebase • diagnose a change • propose a minimal patch • test • verify</p>
</div>
""", unsafe_allow_html=True)

with st.sidebar:
    st.header("🤖 Agent control center")
    st.markdown("**Goal:** Make safe, minimal software changes and prove them with tests.")
    st.divider()
    st.markdown("### Workflow")
    st.markdown("1. 🔎 Scan repository\n2. 🧠 Understand request\n3. 🛠️ Propose patch\n4. 👤 Review / approve\n5. 🧪 Run tests\n6. ✅ Verify result")
    st.divider()
    api_ready = bool(__import__("os").getenv("OPENAI_API_KEY"))
    st.metric("AI patch mode", "LLM enabled" if api_ready else "Demo / local")
    st.caption("LLM mode is used for arbitrary repositories when OPENAI_API_KEY is configured. The built-in demo works without a key.")

# Top-level workflow visual
cols = st.columns(6)
steps = [("01", "Scan", "Repository"), ("02", "Understand", "Task"), ("03", "Patch", "Minimal edit"), ("04", "Approve", "Human review"), ("05", "Test", "Existing tests"), ("06", "Verify", "Proof")]
for col, (num, title, sub) in zip(cols, steps):
    with col:
        st.markdown(f'<div class="step"><b>{num} · {title}</b><br><span class="small">{sub}</span></div>', unsafe_allow_html=True)

st.write("")

def show_workspace(root: Path, task: str, key_suffix: str):
    summary = inspect_repo(root)

    st.header("🔎 1. Repository understanding")
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Files inspected", summary["file_count"])
    m2.metric("Test / config files", summary["test_count"])
    m3.metric("Source types", len({Path(f).suffix.lower() for f in summary["files"] if Path(f).suffix}))
    m4.metric("Safety", "Path checked")
    st.info(summary["summary"])
    with st.expander("📁 View repository file map", expanded=False):
        st.code("\n".join(summary["files"]) or "(no supported source files found)")

    st.header("🎯 2. Requested change")
    st.markdown(f"> {task}")

    bc1, bc2 = st.columns([1, 1])
    with bc1:
        if st.button("🧪 Run baseline tests", use_container_width=True, key="baseline_"+key_suffix):
            with st.spinner("Running the repository tests before any change..."):
                st.session_state["baseline_outcome"] = {"root": str(root), "tests": run_tests(root)}
    with bc2:
        if st.button("🧠 Analyze repository and propose patch", type="primary", use_container_width=True, key="analyze_"+key_suffix):
            with st.spinner("Agent is exploring the repository and reasoning about the requested change..."):
                st.session_state["patch_result"] = propose_patch(root, task)
            st.session_state["patch_root"] = str(root)
            st.session_state.pop("test_outcome", None)

    baseline = st.session_state.get("baseline_outcome")
    if baseline and baseline.get("root") == str(root):
        bt = baseline["tests"]
        if bt.get("available"):
            if bt.get("passed"):
                st.success("Baseline tests are already passing. The agent will preserve this behavior.")
            else:
                st.warning("Baseline tests currently fail. PatchPilot will use the failure as evidence and will verify the repository again after an approved patch.")
            with st.expander("View baseline test output"):
                st.code(bt.get("output", "")[-5000:])
        else:
            st.info(bt.get("output", "No baseline test runner detected."))

    result = st.session_state.get("patch_result")
    if result and st.session_state.get("patch_root") == str(root):
        st.header("🛠️ 3. Proposed change")
        st.success(f"Patch proposal generated · {result.get('source', 'agent')}")
        st.markdown(f"**Agent reasoning:** {result.get('explanation', '')}")
        patches = result.get("patches", [])
        if patches:
            st.caption(f"Minimal patch scope: {len(patches)} file(s) · Existing public API is preserved where applicable.")
            for patch in patches:
                st.markdown(f"**Changed file:** `{patch['path']}`")
                st.code(patch["new_content"], language="python" if patch["path"].endswith(".py") else "text")
            st.warning("Human approval gate: the patch is not applied until you click the button below.")
            if st.button("✅ Approve patch, apply change & run tests", key="apply_"+key_suffix, use_container_width=True):
                with st.spinner("Applying approved patch and running the existing test suite..."):
                    applied = apply_patch(root, patches)
                    tests = run_tests(root)
                st.session_state["test_outcome"] = {"root": str(root), "applied": applied, "tests": tests}
        else:
            st.warning(result.get("explanation", "No safe automatic patch was generated."))
            st.info("Safety rule: PatchPilot refuses to guess when the evidence is insufficient. For broader arbitrary-repository fixes, configure OPENAI_API_KEY; common high-confidence arithmetic fixes can also be handled locally without a key.")

    outcome = st.session_state.get("test_outcome")
    if outcome and outcome["root"] == str(root):
        st.header("🧪 4. Verification report")
        tests = outcome["tests"]
        passed = tests["passed"]
        if passed:
            st.success("ALL TESTS PASSED ✅ — The proposed change was verified successfully.")
        else:
            st.error("TESTS FAILED ❌ — The change needs another iteration.")
        a, b, c = st.columns(3)
        a.metric("Verification", "PASS" if passed else "FAIL")
        b.metric("Changed files", len(outcome["applied"].get("changed", [])))
        c.metric("Test command", "pytest -q" if "pytest" in tests["command"] else "unittest")
        st.markdown("**Changed files**")
        for f in outcome["applied"].get("changed", []):
            st.code(f)
        st.markdown("**Test execution output**")
        st.code(tests["output"][-6000:] or "No test output")
        report = {
            "project": "PatchPilot",
            "task": task,
            "changed_files": outcome["applied"].get("changed", []),
            "tests_passed": passed,
            "test_command": tests["command"],
            "test_output": tests["output"][-6000:]
        }
        st.download_button("📄 Download verification report", json.dumps(report, indent=2), "verification_report.json", "application/json", use_container_width=True)


tab1, tab2 = st.tabs(["🚀 Built-in demo", "📦 Upload repository ZIP"])

with tab1:
    if "demo_root" not in st.session_state:
        st.session_state["demo_root"] = str(make_demo_repo())
    demo = Path(st.session_state["demo_root"])
    c1, c2 = st.columns([5, 1])
    with c1:
        st.subheader("Controlled demonstration workspace")
        st.caption("A small repository with a real failing business-logic test. Designed for a reliable live presentation.")
    with c2:
        if st.button("Reset demo", use_container_width=True):
            st.session_state["demo_root"] = str(make_demo_repo())
            st.session_state.pop("patch_result", None)
            st.session_state.pop("test_outcome", None)
            st.rerun()
    show_workspace(
        demo,
        "Fix the off-by-one bug in src/discount.py so a 10% discount is calculated correctly. Keep the public function name and signature unchanged, and make all existing tests pass.",
        "demo"
    )

with tab2:
    st.subheader("Analyze a real repository")
    st.caption("Upload a ZIP, describe the requested change, run a baseline test, then let PatchPilot propose, apply and verify a minimal patch. High-confidence local repairs work without a key; broader AI repairs use OPENAI_API_KEY.")
    uploaded = st.file_uploader("Repository ZIP", type=["zip"])
    task = st.text_area("Change request / bug report", placeholder="Example: Find and fix the login validation bug. Preserve existing functionality and make all existing tests pass.", height=120)
    if uploaded and st.button("📂 Load repository", type="primary"):
        try:
            workspace = Path(tempfile.mkdtemp(prefix="patchpilot_"))
            safe_extract_zip(uploaded.getvalue(), workspace)
            st.session_state["upload_root"] = str(workspace)
            st.session_state.pop("patch_result", None)
            st.session_state.pop("test_outcome", None)
            st.success("Repository loaded and safely extracted.")
        except Exception as exc:
            st.error(f"Could not load ZIP safely: {exc}")
    if st.session_state.get("upload_root"):
        show_workspace(Path(st.session_state["upload_root"]), task or "Inspect the repository and identify the files relevant to this request.", "upload")
