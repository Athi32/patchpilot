# Architecture

Repository scanner → patch proposer → path validation → human approval → tests → verification report.
