# Demo

Show the broken discount test, analyze, apply the one-file patch, and show tests passing.
