def apply_discount(price, percent):
    """Return price after applying percent discount."""
    discount = price * percent / 100
    return price + discount  # BUG: should subtract the discount
