import unittest
from src.discount import apply_discount

class DiscountTests(unittest.TestCase):
    def test_ten_percent_discount(self):
        self.assertAlmostEqual(apply_discount(100, 10), 90)

    def test_zero_discount(self):
        self.assertAlmostEqual(apply_discount(50, 0), 50)

if __name__ == "__main__":
    unittest.main()
